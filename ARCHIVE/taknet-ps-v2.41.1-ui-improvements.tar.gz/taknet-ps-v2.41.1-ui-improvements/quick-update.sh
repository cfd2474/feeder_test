#!/bin/bash

# TAKNET-PS v2.41.1 Quick Update Script
# UI Improvements: Enable All button + Popup feedback for FR24/FlightAware

set -e

echo "=========================================="
echo "TAKNET-PS v2.41.1 UI Improvements"
echo "=========================================="
echo ""
echo "This updates:"
echo "  • Adds 'Enable All' button for accountless feeds"
echo "  • Adds popup feedback to FR24 setup"
echo "  • Adds popup feedback to FlightAware setup"
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "❌ Error: This script must be run as root"
    echo "   Please run: sudo bash quick-update.sh"
    exit 1
fi

# Check if installation exists
if [ ! -d "/opt/adsb/web/templates" ]; then
    echo "❌ Error: TAKNET-PS not found"
    echo "   Expected: /opt/adsb/web/templates/"
    exit 1
fi

# Backup current templates
echo "📦 Creating backups..."
TIMESTAMP=$(date +%Y%m%d-%H%M%S)
cp /opt/adsb/web/templates/feeds.html \
   /opt/adsb/web/templates/feeds.html.backup-$TIMESTAMP
cp /opt/adsb/web/templates/feeds-account-required.html \
   /opt/adsb/web/templates/feeds-account-required.html.backup-$TIMESTAMP
echo "   ✓ Backups created"
echo ""

# Install new templates
echo "📥 Installing updated templates..."
cp web/templates/feeds.html /opt/adsb/web/templates/
cp web/templates/feeds-account-required.html /opt/adsb/web/templates/
echo "   ✓ Templates installed"
echo ""

# Restart web service
echo "🔄 Restarting web service..."
systemctl restart adsb-web.service
sleep 2
echo ""

# Verify
if systemctl is-active --quiet adsb-web.service; then
    echo "=========================================="
    echo "✅ UPDATE SUCCESSFUL!"
    echo "=========================================="
    echo ""
    echo "New features:"
    echo "  ✓ 'Enable All' button for accountless feeds"
    echo "  ✓ Popup feedback for FlightAware setup"
    echo "  ✓ Popup feedback for FR24 setup"
    echo ""
    echo "Visit feed selection page to see changes:"
    echo "  http://taknet-ps.local/feeds"
    echo ""
else
    echo "❌ Web service failed to start"
    echo ""
    echo "Rolling back..."
    cp /opt/adsb/web/templates/feeds.html.backup-$TIMESTAMP \
       /opt/adsb/web/templates/feeds.html
    cp /opt/adsb/web/templates/feeds-account-required.html.backup-$TIMESTAMP \
       /opt/adsb/web/templates/feeds-account-required.html
    systemctl restart adsb-web.service
    echo "Rollback complete"
    exit 1
fi

echo "Update complete! 🎉"
