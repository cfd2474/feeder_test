# TAKNET-PS v2.41.1 UI Improvements

**Three new UI enhancements for better user experience!**

---

## 🎯 What's New

### 1. ✅ "Enable All" Button
Big green button to enable all accountless feeds with one click!

### 2. 🔔 FlightAware Popup Feedback
Setup shows immediate popup with spinner and success confirmation

### 3. 🔔 FR24 Popup Feedback  
Setup shows immediate popup with registration progress and status

---

## ⚡ Quick Update

```bash
cd /tmp
tar -xzf taknet-ps-v2.41.1-ui-improvements.tar.gz
cd taknet-ps-v2.41.1-ui-improvements
sudo bash quick-update.sh
```

**Time:** 30 seconds  
**Safe:** Yes - automatic backups & rollback

---

## 📦 What's Included

```
├── README.md                         # This file
├── CHANGELOG-v2.41.1.md              # Detailed changes
├── quick-update.sh                   # Automated update
└── web/templates/
    ├── feeds.html                    # Updated with "Enable All"
    └── feeds-account-required.html   # Updated with popup feedback
```

---

## ✨ Features

### "Enable All" Button

**Location:** Feed Selection page, below accountless feeds list

**What it does:**
- Enables all accountless feeds with one click
- Shows progress: "Enabling feeds: 3/5 complete..."
- Success message: "Successfully enabled 5 of 5 feeds"
- Auto-dismisses after 2 seconds

**Feeds included:**
- TAKNET-PS
- airplanes.live
- adsb.fi
- adsb.lol
- ADSBexchange

---

### FlightAware Popup Feedback

**Location:** Account-Required Feeds → FlightAware setup

**New behavior:**
- Click "Save & Enable FlightAware"
- Popup shows: "Generating FlightAware Feeder ID..." (spinner)
- Success: "Feeder ID generated! Opening claim page..." (✓)
- Auto-dismisses after 2 seconds
- Detailed instructions appear below

**For existing IDs:**
- Popup: "Configuring FlightAware feed..."
- Success: "FlightAware feed enabled successfully!" (✓)
- Auto-dismisses

---

### FR24 Popup Feedback

**Location:** Account-Required Feeds → FlightRadar24 setup

**New behavior:**
- Click "Save & Enable FR24"
- Popup shows: "Registering with FlightRadar24..." (spinner)
- Success: "Registration successful! Starting FR24 feed..." (✓)
- Continues: "Starting FR24 feed..."
- Final: "FR24 feed enabled successfully!" (✓)
- Auto-dismisses after 2 seconds

---

## 🔧 Manual Update

### Backup First

```bash
sudo cp /opt/adsb/web/templates/feeds.html \
        /opt/adsb/web/templates/feeds.html.backup

sudo cp /opt/adsb/web/templates/feeds-account-required.html \
        /opt/adsb/web/templates/feeds-account-required.html.backup
```

### Install Updates

```bash
sudo cp web/templates/feeds.html /opt/adsb/web/templates/
sudo cp web/templates/feeds-account-required.html /opt/adsb/web/templates/
sudo systemctl restart adsb-web.service
```

### Verify

```bash
systemctl status adsb-web.service
# Should show "active (running)"
```

---

## ✅ Verification

After update:

1. **Visit feeds page:** http://taknet-ps.local/feeds
2. **Look for green button:** "✓ Enable All Accountless Feeds"
3. **Test enable all:** Click button → see progress popup
4. **Test FlightAware:** Go to account feeds → click setup → see popup
5. **Test FR24:** Enter key/email → click setup → see popup

---

## 🔙 Rollback

If something goes wrong:

```bash
# Restore backups
sudo cp /opt/adsb/web/templates/feeds.html.backup \
        /opt/adsb/web/templates/feeds.html

sudo cp /opt/adsb/web/templates/feeds-account-required.html.backup \
        /opt/adsb/web/templates/feeds-account-required.html

# Restart
sudo systemctl restart adsb-web.service
```

---

## 💡 FAQ

**Q: Will this break my current setup?**  
A: No! These are pure UI improvements. No backend changes.

**Q: Do I need to reconfigure feeds?**  
A: No! All existing configurations remain unchanged.

**Q: Can I still enable feeds individually?**  
A: Yes! Individual checkboxes work exactly as before.

**Q: What if "Enable All" fails?**  
A: It enables feeds one by one. If one fails, others still work.

**Q: Are the popups blocking?**  
A: No, they auto-dismiss after 1.5-3 seconds.

---

## 🐛 Troubleshooting

**Web service won't start:**
```bash
# Check logs
sudo journalctl -u adsb-web.service -n 50

# Rollback
sudo cp /opt/adsb/web/templates/*.backup /opt/adsb/web/templates/
sudo systemctl restart adsb-web.service
```

**"Enable All" button not showing:**
- Clear browser cache
- Hard refresh (Ctrl+Shift+R)
- Check template copied correctly

**Popups not appearing:**
- Clear browser cache
- Check JavaScript console for errors
- Verify templates updated correctly

---

## 📞 Support

**Files:**
- CHANGELOG-v2.41.1.md - Complete technical details
- README.md - This file

**Need help?**
- Check systemd logs: `journalctl -u adsb-web.service`
- Verify templates: `ls -l /opt/adsb/web/templates/`
- Rollback if needed using backup files

---

**Version:** 2.41.1  
**Type:** UI Enhancement  
**Update Time:** 30 seconds  
**Safe:** Yes (automatic backups)  
**Breaking Changes:** None ✅
