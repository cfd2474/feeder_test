# TAKNET-PS v2.41.0 Update Package

**Two New Features:**
1. Docker images pre-download during GitHub install (faster setup!)
2. FlightAware MLAT timing + location verification instructions

---

## Quick Update (30 seconds)

```bash
cd /tmp
tar -xzf taknet-ps-v2.41.0-update.tar.gz
cd taknet-ps-v2.41.0-update
sudo bash quick-update.sh
```

This updates the FlightAware template with new documentation.

---

## What's Included

```
taknet-ps-v2.41.0-update/
├── README.md                         (this file)
├── CHANGELOG-v2.41.0.md              (detailed changes)
├── UPDATE-v2.41.0.md                 (update instructions)
├── quick-update.sh                   (automated update script)
├── install/
│   └── install.sh                    (new installer v2.41.0)
└── web/templates/
    └── feeds-account-required.html   (updated FlightAware page)
```

---

## Features

### 1. Pre-Download Docker Images

**install/install.sh** now downloads images during initial installation:
- Ultrafeeder (~450MB)
- PiAware (~380MB)
- FlightRadar24 (~320MB)

**Result:** Setup wizard takes 30-40 seconds instead of 5-10 minutes!

**Who needs this?**
- New installations from GitHub
- Fresh reinstalls

**Existing users:**
- Images likely already cached
- No action needed

---

### 2. FlightAware Documentation

**web/templates/feeds-account-required.html** now includes:

**MLAT Timing Notice:**
- MLAT takes up to 10 minutes to show "live"
- This is normal behavior
- Users know to be patient

**Location Verification Steps:**
1. Go to flightaware.com/adsb/stats/user/
2. Click gear icon next to feeder name
3. Enter exact coordinates
4. Save changes

**Why this matters:**
- Incorrect location = MLAT errors
- Users now know how to verify

---

## Update Options

### Option 1: Quick Update (Recommended)
```bash
sudo bash quick-update.sh
```
- Updates FlightAware template
- Restarts web service
- Optional: Pre-download images
- **Time: 30 seconds**

### Option 2: Manual Template Update
```bash
sudo cp web/templates/feeds-account-required.html \
        /opt/adsb/web/templates/
sudo systemctl restart adsb-web.service
```

### Option 3: Fresh Install
```bash
# Use new installer for fresh install
curl -fsSL https://raw.githubusercontent.com/cfd2474/feeder_test/main/install/install.sh | sudo bash
```

---

## Verification

After update, check:

```bash
# Template updated?
grep "MLAT Timing" /opt/adsb/web/templates/feeds-account-required.html
# Should show line with "MLAT Timing" text

# Web service running?
systemctl status adsb-web.service
# Should show "active (running)"
```

---

## Support

**Problems?**
1. Check UPDATE-v2.41.0.md for detailed instructions
2. Read CHANGELOG-v2.41.0.md for technical details
3. Check systemd logs: `journalctl -u adsb-web.service -n 20`

**Rollback?**
```bash
# Backup is created automatically
ls /opt/adsb/web/templates/*.backup-*
# Restore if needed:
sudo cp /opt/adsb/web/templates/feeds-account-required.html.backup-* \
        /opt/adsb/web/templates/feeds-account-required.html
sudo systemctl restart adsb-web.service
```

---

**Version:** 2.41.0  
**Date:** 2026-02-08  
**Update Time:** 30 seconds  
**Breaking Changes:** None  
**Safe:** Yes ✅
