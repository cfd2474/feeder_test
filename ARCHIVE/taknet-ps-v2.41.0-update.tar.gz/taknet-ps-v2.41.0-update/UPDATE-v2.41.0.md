# TAKNET-PS v2.41.0 Update Guide

**Quick Summary:** Pre-download Docker images during install + FlightAware MLAT/location instructions

---

## 🎯 What Changed

1. **Install Script:** Docker images now download during initial GitHub install (not during wizard)
2. **FlightAware Docs:** Added MLAT timing notice and location verification steps

---

## 🔄 Updating Existing Installation

### Option 1: Update FlightAware Instructions Only (Recommended)

If you just want the improved FlightAware documentation:

```bash
cd /tmp

# Download new template
wget https://raw.githubusercontent.com/cfd2474/feeder_test/main/web/templates/feeds-account-required.html

# Backup current version
sudo cp /opt/adsb/web/templates/feeds-account-required.html \
        /opt/adsb/web/templates/feeds-account-required.html.backup

# Install new version
sudo cp feeds-account-required.html /opt/adsb/web/templates/

# Restart web service
sudo systemctl restart adsb-web.service

echo "✓ FlightAware instructions updated!"
```

**Benefits:**
- New MLAT timing information
- Location verification steps
- Better user guidance

---

### Option 2: Pre-Download Images Manually

If you want faster future reinstalls:

```bash
# Download all images in parallel
sudo docker pull ghcr.io/sdr-enthusiasts/docker-adsb-ultrafeeder:latest &
sudo docker pull ghcr.io/sdr-enthusiasts/docker-piaware:latest &
sudo docker pull ghcr.io/sdr-enthusiasts/docker-flightradar24:latest &

# Wait for completion
wait

echo "✓ Images cached for fast setup!"
```

**Benefits:**
- Next time you run setup wizard, it'll be instant
- Useful if you're testing/reinstalling frequently

---

### Option 3: Full Reinstall (Complete Fresh Start)

**⚠️ Warning:** This wipes your current installation!

```bash
# Backup your configuration
sudo cp /opt/adsb/config/.env /home/$USER/taknet-ps-env-backup
echo "✓ Config backed up to ~/taknet-ps-env-backup"

# Full reinstall with new installer
curl -fsSL https://raw.githubusercontent.com/cfd2474/feeder_test/main/install/install.sh | sudo bash

# Restore config
sudo cp /home/$USER/taknet-ps-env-backup /opt/adsb/config/.env
sudo systemctl restart ultrafeeder adsb-web

echo "✓ Reinstalled with v2.41.0!"
```

**Benefits:**
- Gets all new features
- Fresh start (good for troubleshooting)
- Images pre-downloaded automatically

---

## 📋 What You Get

### New Install Script Features

```bash
# During initial install, you'll now see:

Pre-downloading Docker images...
  This may take 5-10 minutes depending on connection speed...
  • Ultrafeeder (~450MB)
  • PiAware (~380MB)
  • FlightRadar24 (~320MB)
  Downloading in parallel...
  ✓ Ultrafeeder downloaded
  ✓ PiAware downloaded
  ✓ FlightRadar24 downloaded
✓ All Docker images pre-downloaded (setup wizard will be fast!)
```

**Result:** Setup wizard takes 30-40 seconds instead of 5-10 minutes!

---

### New FlightAware Instructions

On the FlightAware setup page, you'll see a new yellow info box:

```
⏱️ MLAT Status & Location Verification

• MLAT Timing: After setup, MLAT may take up to 10 minutes 
  to show as "live" on FlightAware. This is normal - be patient!

• Verify Location: To ensure accurate position data:
  1. Go to flightaware.com/adsb/stats/user/
  2. Click the gear icon ⚙️ next to your feeder name
  3. Enter your exact coordinates
  4. Save changes

Why? Incorrect location causes MLAT positioning errors!
```

---

## ✅ Verification

After updating, verify changes:

```bash
# Check FlightAware template updated
grep "MLAT Timing" /opt/adsb/web/templates/feeds-account-required.html
# Should output: line with "MLAT Timing" text

# Check images cached
docker images | grep -E "ultrafeeder|piaware|flightradar24"
# Should show three images with "latest" tags

# Check web service running
systemctl status adsb-web.service
# Should show "active (running)"
```

---

## 🎯 Recommended Update Path

**For most users:**
```bash
# Just update FlightAware docs (30 seconds)
cd /tmp
wget https://raw.githubusercontent.com/cfd2474/feeder_test/main/web/templates/feeds-account-required.html
sudo cp feeds-account-required.html /opt/adsb/web/templates/
sudo systemctl restart adsb-web.service
```

**If you're planning to reinstall soon:**
```bash
# Pre-download images now for faster future setup
sudo docker pull ghcr.io/sdr-enthusiasts/docker-adsb-ultrafeeder:latest
sudo docker pull ghcr.io/sdr-enthusiasts/docker-piaware:latest
sudo docker pull ghcr.io/sdr-enthusiasts/docker-flightradar24:latest
```

**If you want everything fresh:**
```bash
# Full reinstall with backup
sudo cp /opt/adsb/config/.env ~/taknet-ps-backup
curl -fsSL https://raw.githubusercontent.com/.../install.sh | sudo bash
# Then restore config if needed
```

---

## 💡 FAQ

**Q: Do I need to update?**  
A: No, but FlightAware docs are helpful. Image pre-download only helps fresh installs.

**Q: Will this break my current setup?**  
A: No! These are additive changes. No breaking changes.

**Q: Should I reinstall or just update templates?**  
A: Just update templates unless you're having issues.

**Q: When should I pre-download images?**  
A: If you're testing/reinstalling frequently, or preparing for offline use.

**Q: What if my images are already downloaded?**  
A: Then you already have the speed benefit! No action needed.

---

## 📞 Support

**Template update not working?**
```bash
# Check file was copied
ls -l /opt/adsb/web/templates/feeds-account-required.html

# Check service restarted
sudo systemctl status adsb-web.service

# Check for errors
sudo journalctl -u adsb-web.service -n 20
```

**Need help?**
- Check CHANGELOG-v2.41.0.md for details
- Verify installation with commands above
- Check systemd logs for errors

---

**Update Time:** 30 seconds (template only) or 5-10 minutes (full reinstall)  
**Difficulty:** Easy  
**Breaking Changes:** None  
**Recommended:** Yes (especially for FlightAware users!)
