#!/bin/bash

# TAKNET-PS v2.41.0 Quick Update Script
# Updates FlightAware instructions template

set -e

echo "=========================================="
echo "TAKNET-PS v2.41.0 Update"
echo "=========================================="
echo ""
echo "This updates the FlightAware template with:"
echo "  • MLAT timing information (10 min wait)"
echo "  • Location verification instructions"
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "❌ Error: This script must be run as root"
    echo "   Please run: sudo bash quick-update.sh"
    exit 1
fi

# Check if installation exists
if [ ! -f "/opt/adsb/web/templates/feeds-account-required.html" ]; then
    echo "❌ Error: TAKNET-PS not found"
    echo "   Expected: /opt/adsb/web/templates/"
    exit 1
fi

# Backup current template
echo "📦 Creating backup..."
cp /opt/adsb/web/templates/feeds-account-required.html \
   /opt/adsb/web/templates/feeds-account-required.html.backup-$(date +%Y%m%d-%H%M%S)
echo "   ✓ Backup created"
echo ""

# Install new template
echo "📥 Installing updated template..."
cp web/templates/feeds-account-required.html /opt/adsb/web/templates/
echo "   ✓ Template installed"
echo ""

# Restart web service
echo "🔄 Restarting web service..."
systemctl restart adsb-web.service
sleep 2
echo ""

# Verify
if systemctl is-active --quiet adsb-web.service; then
    echo "=========================================="
    echo "✅ UPDATE SUCCESSFUL!"
    echo "=========================================="
    echo ""
    echo "New features:"
    echo "  • MLAT timing notice (10 min wait is normal)"
    echo "  • Location verification steps"
    echo ""
    echo "Visit FlightAware setup page to see changes:"
    echo "  http://taknet-ps.local/feeds-account-required"
    echo ""
else
    echo "❌ Web service failed to start"
    echo ""
    echo "Rolling back..."
    BACKUP=$(ls -t /opt/adsb/web/templates/feeds-account-required.html.backup-* | head -1)
    cp "$BACKUP" /opt/adsb/web/templates/feeds-account-required.html
    systemctl restart adsb-web.service
    echo "Rollback complete"
    exit 1
fi

# Optional: Pre-download images
echo "=========================================="
echo "Optional: Pre-Download Docker Images"
echo "=========================================="
echo ""
echo "This caches images for faster future setups."
echo "Takes 5-10 minutes. Skip if already downloaded."
echo ""
read -p "Pre-download images now? (y/N): " -n 1 -r
echo ""

if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo ""
    echo "Downloading images in parallel..."
    docker pull ghcr.io/sdr-enthusiasts/docker-adsb-ultrafeeder:latest &
    docker pull ghcr.io/sdr-enthusiasts/docker-piaware:latest &
    docker pull ghcr.io/sdr-enthusiasts/docker-flightradar24:latest &
    wait
    echo "✓ All images downloaded!"
else
    echo "Skipped image download."
fi

echo ""
echo "Update complete! 🎉"
